# BandLabTest
@auther kkbit233@gmail.com

#pre-requisite :-

1.open this url into browser:
https://github.com/kkmishra233/BandLabTest
2.find clone or download option and download the project in zip format 
3.unzip the suite
4.import suite in any IDE as Maven Project

#Setup :-

1.modify test data in jherkins file present at location : src/test/Resources/*.feature
2.By default this suite will run once with default test data

#Run-suite :-

run the following class as Junit : /src/test/java/BandLab/TestUserShout/TestRunner.java 

#tools/technologies :-

1.java
2.cucumber
3.Junit
4.Selenium